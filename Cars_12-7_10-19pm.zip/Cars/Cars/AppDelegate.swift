//
//  AppDelegate.swift
//  MusicAlbums
//
//  Created by Osman Balci on 2/20/22.
//  Copyright © 2022 Osman Balci. All rights reserved.
//

import SwiftUI
import UIKit

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions
                     launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
       
        /*
        ************************************
        *   Create Book and Photo Database   *
        ************************************
        */
        createMainCarStructs()      // Given in BooksPhotosData.swift
//        print("done")
        // Get Permission to Obtain User's Current Location
        getPermissionForLocation()      // Given in CurrentLocation.swift
        
        return true
    }
}
