//
//  AddCar.swift
//  Cars
//
//  Created by Akhil Kamalesh on 11/27/22.
//

import SwiftUI
import CoreData

struct AddCar: View {
    
    // Enable this view to be dismissed to go back to the previous view
    @Environment(\.dismiss) private var dismiss
    
    // ✳️ Core Data managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // ❎ Core Data FetchRequest returning all Company entities from the database
    @FetchRequest(fetchRequest: Car.allCarsFetchRequest()) var allCars: FetchedResults<Car>
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    //---------------
    // Alert Messages
    //---------------
    @State private var showAlertMessage = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
    //---------------
    // Car Entity
    //---------------
    @State private var make = ""
    @State private var model = ""
    @State private var year = ""
    @State private var imageUrl = ""
    
    @State private var classType = ""
    @State private var drive = ""
    @State private var cityMpg = ""
    @State private var comboMpg = ""
    @State private var highMpg = ""
    @State private var cylinder = ""

    /*
     ---------------
     MARK: Body View
     ---------------
     */
    var body: some View {
        
        Form {
            /*
             **********************
             *   Company Entity   *
             **********************
             */
            Group {
                Section(header: Text("Car Make")) {
                    TextField("Enter a car make", text: $make)
                }
                Section(header: Text("Car Model")) {
                    TextField("Enter a car model", text: $model)
                }
                Section(header: Text("Car Year")) {
                    TextField("Enter a car year", text: $year)
                }
                Section(header: Text("Car Class Type")) {
                    TextField("Enter a car class type", text: $classType)
                }
                Section(header: Text("Car Drive")) {
                    TextField("Enter a car drive", text: $drive)
                }

            }
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .disableAutocorrection(true)
            Group {
                
                Section(header: Text("Car City MPG")) {
                    TextField("Enter a car city mpg", text: $cityMpg)
                }
                
                Section(header: Text("Car Combination MPG")) {
                    TextField("Enter a car combination mpg", text: $comboMpg)
                }
                
                Section(header: Text("Car Highway MPG")) {
                    TextField("Enter a car highway mpg", text: $highMpg)
                }
                
                Section(header: Text("Car Cylinders")) {
                    TextField("Enter a car cylinder amount", text: $cylinder)
                }
                
                Section(header: Text("Car Image")) {
                    TextField("Enter a car image url", text: $imageUrl)
                }
                
            }
        }   // End of Form
            .font(.system(size: 14))
            .disableAutocorrection(true)
            .autocapitalization(.none)
        
            .navigationBarTitle(Text("Add Car"), displayMode: .inline)
            .navigationBarItems(trailing:
                Button("Save") {
                    if inputDataValidated() {
                        saveNewTrip()
                        
                        showAlertMessage = true
                        alertTitle = "Car Added!"
                        alertMessage = "New car is added to your favorites list."
                    } else {
                        showAlertMessage = true
                        alertTitle = "Missing Input Data!"
                        alertMessage = "All data fields are required"
                    }
                }
            )
        
            .alert(alertTitle, isPresented: $showAlertMessage, actions: {
                  Button("OK") {
                      if alertTitle == "Car Added!" {
                          // Dismiss this view and go back to the previous view
                          dismiss()
                      }
                  }
                }, message: {
                  Text(alertMessage)
                })
        
    }   // End of body var
    
    /*
     ---------------------------
     MARK: Input Data Validation
     ---------------------------
     */
    func inputDataValidated() -> Bool {
        
        if make.isEmpty || model.isEmpty || classType.isEmpty {
            return false
        }

        return true
    }
    
    /*
     ----------------------
     MARK: Save New Company
     ----------------------
     */
    func saveNewTrip() {
        /*
         ===============================
         *   Car Entity Creation   *
         ===============================
         */
        
        // 1️⃣ Create an instance of the Company entity in managedObjectContext
        let carEntity = Car(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attributes
        carEntity.orderNumber = (allCars.count + 1) as NSNumber
        carEntity.make = make
        carEntity.model = model
        
        if let yearInt = Int(year){
            let yearInput = NSNumber(value: yearInt)
            carEntity.year = yearInput
        }
        
        carEntity.imageUrl = imageUrl
        carEntity.classType = classType
        carEntity.drive = drive

        if let cityInt = Int(cityMpg){
            let cityInput = NSNumber(value: cityInt)
            carEntity.city_mpg = cityInput
        }
        
        if let comInt = Int(comboMpg){
            let comInput = NSNumber(value: comInt)
            carEntity.combination_mpg = comInput
        }
        
        if let highInt = Int(highMpg){
            let highInput = NSNumber(value: highInt)
            carEntity.highway_mpg = highInput
        }
        
        if let cylinderInt = Int(cylinder){
            let cylinderInput = NSNumber(value: cylinderInt)
            carEntity.cylinders = cylinderInput
        }

        // ❎ Save Changes to Core Data Database
        PersistenceController.shared.saveContext()
        
        // Toggle database change indicator so that its subscribers can refresh their views
        databaseChange.indicator.toggle()
        
    }   // End of func saveNewCompany
    
}

struct AddCar_Previews: PreviewProvider {
    static var previews: some View {
        AddCar()
    }
}

