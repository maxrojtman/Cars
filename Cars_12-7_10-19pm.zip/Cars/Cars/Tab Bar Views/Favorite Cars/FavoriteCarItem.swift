//
//  FavoriteCarItem.swift
//  Cars
//
//  Created by Akhil Kamalesh on 11/27/22.
//

import SwiftUI

struct FavoriteCarItem: View {
    
    // ✳️ Input parameter: Core Data Company Entity instance reference
    let car: Car
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    @AppStorage("darkMode") private var darkMode = false
    
    var body: some View {
        HStack {
            getImageFromUrl(url: car.imageUrl ?? "", defaultFilename: "ImageUnavailable")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 115.0, height: 120.0)
                .background(darkMode ? Color.gray : Color.white.opacity(0.0))
            
            VStack(alignment: .leading) {
                HStack {
                    Text("Make: ")
                        .font(.system(size: 14, weight: .medium, design: .monospaced))
                    Text(car.make ?? "")
                        .font(.system(size: 14, weight: .medium, design: .serif))
                }
                    
                HStack {
                    Text("Model: ")
                        .font(.system(size: 14, weight: .medium, design: .monospaced))
                    Text(car.model ?? "")
                        .font(.system(size: 14, weight: .medium, design: .serif))
                }
                HStack {
                    Text("Car Info: ")
                        .font(.system(size: 14, weight: .medium, design: .monospaced))
                    Text(car.classType ?? "")
                        .font(.system(size: 14, weight: .medium, design: .serif))
                }
            }
            .font(.system(size: 14))
        }
    }
    
}

