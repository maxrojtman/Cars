//
//  FavoriteCarList.swift
//  Cars
//
//  Created by Akhil Kamalesh on 11/27/22.
//

import SwiftUI
import CoreData

struct FavoriteCarList: View {
    
    // ❎ Core Data managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // ❎ Core Data FetchRequest returning all Company entities from the database
    @FetchRequest(fetchRequest: Car.allCarsFetchRequest()) var allCars: FetchedResults<Car>
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    @State private var toBeDeleted: IndexSet?
    @State private var showConfirmation = false
    
    var body: some View {
        NavigationView {
            List {
                /*
                 Each NSManagedObject has internally assigned unique ObjectIdentifier
                 used by ForEach to display the Companies in a dynamic scrollable list.
                 */
                ForEach(allCars) { aCar in
                    NavigationLink(destination: FavoriteCarDetails(car: aCar)) {
                        FavoriteCarItem(car: aCar)
                            .alert(isPresented: $showConfirmation) {
                                Alert(title: Text("Delete Confirmation"),
                                      message: Text("Are you sure to permanently delete the car? It cannot be undone."),
                                      primaryButton: .destructive(Text("Delete")) {
                                    /*
                                    'toBeDeleted (IndexSet).first' is an unsafe pointer to the index number of the array
                                     element to be deleted. It is nil if the array is empty. Process it as an optional.
                                    */
                                    if let index = toBeDeleted?.first {
                                       
                                        let carToDelete = allCars[index]
                                        
                                        // ❎ Delete Selected Company entity from the database
                                        managedObjectContext.delete(carToDelete)

                                        // ❎ Save Changes to Core Data Database
                                        PersistenceController.shared.saveContext()
                                        
                                        // Toggle database change indicator so that its subscribers can refresh their views
                                        databaseChange.indicator.toggle()
                                    }
                                    toBeDeleted = nil
                                }, secondaryButton: .cancel() {
                                    toBeDeleted = nil
                                }
                            )
                        }   // End of alert
                    }
                }
                .onDelete(perform: delete)
                .onMove(perform: move)
                
            }   // End of List
                .navigationBarTitle(Text("Favorite Cars"), displayMode: .inline)
                
                // Place the Edit button on left and Add (+) button on right of the navigation bar
                .navigationBarItems(leading: EditButton(), trailing:
                    NavigationLink(destination: AddCar()) {
                        Image(systemName: "plus")
                })
            
        }   // End of NavigationView
        .customNavigationViewStyle()  // Given in NavigationStyle
        
    }   // End of body var
    
    /*
     -----------------------------
     MARK: Delete Selected Company
     -----------------------------
     */
    func delete(at offsets: IndexSet) {
        
         toBeDeleted = offsets
         showConfirmation = true
     }
    
    /*
     ---------------------------
     MARK: Move Selected Company
     ---------------------------
     */
    private func move(from source: IndexSet, to destination: Int) {
        
        // Create an array of Company entities from allCompanies fetched from the database
        var arrayOfAllCars: [Car] = allCars.map{ $0 }

        // ❎ Perform the move operation on the array
        arrayOfAllCars.move(fromOffsets: source, toOffset: destination )

        /*
         'stride' returns a sequence from a starting value toward, and possibly including,
         an end value, stepping by the specified amount.
         
         Update the orderNumber attribute in reverse order starting from the end toward the first.
         */
        for index in stride(from: arrayOfAllCars.count - 1, through: 0, by: -1) {
            
            arrayOfAllCars[index].orderNumber = Int32(index) as NSNumber
        }
        
        // ❎ Save Changes to Core Data Database
        PersistenceController.shared.saveContext()
        
        // Toggle database change indicator so that its subscribers can refresh their views
        databaseChange.indicator.toggle()
    }
    
}   // End of struct


struct FavoritesList_Previews: PreviewProvider {
    static var previews: some View {
        FavoriteCarList()
    }
}


