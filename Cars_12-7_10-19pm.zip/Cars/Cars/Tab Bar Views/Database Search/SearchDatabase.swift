//
//  SearchDatabase.swift
//  TravelAid
//
//  Created by Akhil Kamalesh on 11/13/22.
//  Copyright © 2022 Akhil Kamalesh. All rights reserved.
//

import SwiftUI
import CoreData

// Global Variables
var searchCategory = ""
var searchQuery = ""

struct SearchDatabase: View {
    
    let searchCategoriesList = ["Make", "Model", "Year", "Class", "Cylinders", "Combination MPG"
    , "Highway MPG", "City MPG", "Drive", "Fuel Type"]
    @State private var selectedSearchCategoryIndex = 2
    
//    let ratingChoices = ["1", "2", "3", "4", "5"]
//    @State private var ratingIndex = 2  // Default: "Average"
    
    @State private var compound = ""
    @State private var searchFieldValue = ""
    @State private var searchCompleted = false
    
    //---------------
    // Alert Messages
    //---------------
    @State private var showAlertMessage = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Select a Search Category")) {
                   
                    Picker("", selection: $selectedSearchCategoryIndex) {
                        ForEach(0 ..< searchCategoriesList.count, id: \.self) {
                            Text(searchCategoriesList[$0])
                        }
                    }
                    .pickerStyle(WheelPickerStyle())
                    .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
                   
                }
                //if selectedSearchCategoryIndex != 0 && selectedSearchCategoryIndex != 2{
                Section(header: Text("Search Query under Selected Category")) {
                    HStack {
                        TextField("Enter Search Query", text: $searchFieldValue)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .disableAutocorrection(true)
                            .autocapitalization(.none)
                       
                        // Button to clear the text field
                        Button(action: {
                            searchFieldValue = ""
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }   // End of HStack
                }
                Section(header: Text("Search Database")) {
                    HStack {
                        Spacer()
                        Button(searchCompleted ? "Search Completed" : "Search") {
                            if inputDataValidated() {
                                searchDB()
                                searchCompleted = true
                            } else {
                                showAlertMessage = true
                                alertTitle = "Missing Input Data!"
                                alertMessage = "Please enter a database search query!"
                            }
                        }
                        .tint(.blue)
                        .buttonStyle(.bordered)
                        .buttonBorderShape(.capsule)

                        Spacer()
                    }   // End of HStack
                }
                if searchCompleted {
                    Section(header: Text("List Car Found")) {
                        NavigationLink(destination: showSearchResults) {
                            HStack {
                                Image(systemName: "list.bullet")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                                Text("List Cars Found")
                                    .font(.system(size: 16))
                            }
                            .foregroundColor(.blue)
                        }
                    }
                    Section(header: Text("Clear")) {
                        HStack {
                            Spacer()
                            Button("Clear") {
                                searchCompleted = false
                                searchFieldValue = ""
                                compound = ""
                            }
                            .tint(.blue)
                            .buttonStyle(.bordered)
                            .buttonBorderShape(.capsule)
                            
                            Spacer()
                        }
                    }
                }
            
            }   // End of Form
            .navigationBarTitle(Text("Search Database"), displayMode: .inline)
            .alert(alertTitle, isPresented: $showAlertMessage, actions: {
                  Button("OK") {}
                }, message: {
                  Text(alertMessage)
                })
            
        }   // End of NavigationView
        .customNavigationViewStyle()  // Given in NavigationStyle
        
    }   // End of body var
    
    /*
     ---------------------
     MARK: Search Database
     ---------------------
     */
    func searchDB() {
        
        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        let queryTrimmed = searchFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let genreSearchQueryTrimmed = compound.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // searchCategory and searchQuery are global search parameters defined on top of this file

        searchCategory = searchCategoriesList[selectedSearchCategoryIndex]
        
//        if selectedSearchCategoryIndex == 0 {
//            // Compound search category
//            searchCategory = "Compound"
//            searchQuery = genreSearchQueryTrimmed + "AND" + String(selectedRatingIndex+1)
//
//        }else if selectedSearchCategoryIndex == 2{
//            //let ratingQuery = selectedRatingIndex
//            searchCategory = searchCategoriesList[selectedSearchCategoryIndex]
//            searchQuery = String(selectedRatingIndex+1)
//        } else {
            // Other search categories
        print(searchCategory)
        searchCategory = searchCategoriesList[selectedSearchCategoryIndex]
        searchQuery = queryTrimmed
        //}

        // Public function conductDatabaseSearch is given in DatabaseSearch.swift
        conductDatabaseSearch()
    }
    
    /*
     -------------------------
     MARK: Show Search Results
     -------------------------
     */
    var showSearchResults: some View {
        
        // Global array databaseSearchResults is given in DatabaseSearch.swift
        if databaseSearchResults.isEmpty {
            return AnyView(NotFound(message: "Database Search Produced No Results!\n\nThe database did not return any value for the given search query!"))
        }
        
        return AnyView(SearchItemList())
    }
    
    /*
     ---------------------------
     MARK: Input Data Validation
     ---------------------------
     */
    func inputDataValidated() -> Bool {

        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        let queryTrimmed = searchFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if (queryTrimmed.isEmpty) {
            return false
        }
        
        return true
    }
}

struct SearchDatabase_Previews: PreviewProvider {
    static var previews: some View {
        SearchDatabase()
    }
}
