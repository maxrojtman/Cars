//
//  SearchResultDetails.swift
//  Cars
//
//  Created by Akhil Kamalesh on 11/28/22.
//

import SwiftUI
import MapKit

struct SearchResultDetails: View {
    
    // ✳️ Input parameter: Core Data Company Entity instance reference
    let car: Car
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    @AppStorage("darkMode") private var darkMode = false
    
    //---------
    // Map View
    //---------
//    @State private var selectedMapTypeIndex = 0
//    var mapTypes = ["Standard", "Satellite", "Hybrid", "Globe"]
    
    //---------------
    // Alert Messages
    //---------------
    @State private var showAlertMessage = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
    var body: some View {
        Form {
            Group {
                Section(header: Text("Car Make")) {
                    Text(car.make ?? "")
                }
                Section(header: Text("Car Model")) {
                    Text(car.model ?? "")
                }
                Section(header: Text("Car Year")) {
                    Text(car.year!.stringValue)
                }
                Section(header: Text("Car Photo")) {
                    getImageFromUrl(url: car.imageUrl ?? "", defaultFilename: "ImageUnavailable")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 300)
                        .background(darkMode ? Color.gray : Color.white.opacity(0.0))
                }
                Section(header: Text("Car Class Type")) {
                    Text(car.classType ?? "")
                }
            }
            Group {

                Section(header: Text("Car Drive")) {
                    Text(car.drive ?? "")
                }

                Section(header: Text("Car City MPG")) {
                    Text(car.city_mpg!.stringValue)
                }

                Section(header: Text("Car Combination MPG")) {
                    Text(car.combination_mpg!.stringValue)
                }

                Section(header: Text("Car Highway MPG")) {
                    Text(car.highway_mpg!.stringValue)
                }

                Section(header: Text("Car Cylinders")) {
                    Text(car.cylinders!.stringValue)
                }

            }
        }   // End of Form
        .font(.system(size: 14))
        .navigationBarTitle(Text("Car Details"), displayMode: .inline)
        .alert(alertTitle, isPresented: $showAlertMessage, actions: {
            Button("OK") {}
        }, message: {
            Text(alertMessage)
        })
        
    }   // End of body var
}



