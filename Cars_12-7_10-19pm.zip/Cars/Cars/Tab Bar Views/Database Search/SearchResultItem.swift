//
//  SearchResultItem.swift
//  Cars
//
//  Created by Akhil Kamalesh on 11/28/22.
//

import SwiftUI

struct SearchResultItem: View {
    
    // ✳️ Input parameter: Core Data Company Entity instance reference
    let car: Car
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    @AppStorage("darkMode") private var darkMode = false
    
    var body: some View {
        HStack {
            getImageFromUrl(url: car.imageUrl ?? "", defaultFilename: "ImageUnavailable")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100.0, height: 100.0)
                .background(darkMode ? Color.gray : Color.white.opacity(0.0))
            
            VStack(alignment: .leading) {
                Text(car.make ?? "")
                Text(car.model ?? "")
                Text(car.classType ?? "")
            }
            .font(.system(size: 14))
        }
    }
    
}


