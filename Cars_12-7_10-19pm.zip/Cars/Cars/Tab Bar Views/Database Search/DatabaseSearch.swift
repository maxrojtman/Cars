//
//  DatabaseSearch.swift
//  Cars
//
//  Created by Akhil Kamalesh on 11/28/22.
//

import SwiftUI
import CoreData

// Global variable to contain the search results
var databaseSearchResults = [Car]()

public func conductDatabaseSearch() {
    
    let managedObjectContext: NSManagedObjectContext = PersistenceController.shared.persistentContainer.viewContext
    
    // Initialize the global variable to contain the search results
    databaseSearchResults = [Car]()

    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<Car>(entityName: "Car")
    
    // List the fetched ParkVisit entities in alphabetical order with respect to park full name.
    fetchRequest.sortDescriptors = [ NSSortDescriptor(key: "orderNumber", ascending: true) ]
    
    print(fetchRequest.description)
    
    // 2️⃣ Define the Search Criteria
    
    switch searchCategory {
    case "Make":
        print("inside make")
        fetchRequest.predicate = NSPredicate(format: "make CONTAINS[c] %@", searchQuery)
    case "Model":
        print("inside model")
        fetchRequest.predicate = NSPredicate(format: "model CONTAINS[c] %@", searchQuery)
    case "Year":
        print("inside year")
        fetchRequest.predicate = NSPredicate(format: "year == %i", Int(searchQuery)!)
    case "Class":
        print("inside class")
        fetchRequest.predicate = NSPredicate(format: "classType CONTAINS[c] %@", searchQuery)
    case "Cylinders":
        print("inside cylinders")
        fetchRequest.predicate = NSPredicate(format: "cylinders == %i", Int(searchQuery)!)
    case "Highway MPG":
        print("inside highway mpg")
        fetchRequest.predicate = NSPredicate(format: "highway_mpg == %i", Int(searchQuery)!)
    case "Combination MPG":
        print("inside combo mpg")
        fetchRequest.predicate = NSPredicate(format: "combination_mpg == %i", Int(searchQuery)!)
    case "City MPG":
        print("inside city mpg")
        fetchRequest.predicate = NSPredicate(format: "city_mpg == %i", Int(searchQuery)!)
    case "Drive":
        print("inside drive")
        fetchRequest.predicate = NSPredicate(format: "drive CONTAINS[c] %@", searchQuery)
    case "Fuel Type":
        print("inside fuel type")
        fetchRequest.predicate = NSPredicate(format: "fuel_type CONTAINS[c] %@", searchQuery)
    default:
        print("Search category is out of range!")
    }
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
    } catch {
        print("fetchRequest for trip failed!")
    }
}
