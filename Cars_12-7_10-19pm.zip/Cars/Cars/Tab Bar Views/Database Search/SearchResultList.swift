//
//  SearchResultList.swift
//  Cars
//
//  Created by Akhil Kamalesh on 11/28/22.
//

import SwiftUI

struct SearchItemList: View {
    var body: some View {
        List {
            ForEach(databaseSearchResults) { aCar in
                NavigationLink(destination: SearchResultDetails(car: aCar)) {
                    SearchResultItem(car: aCar)
                }
            }
        }
        .navigationBarTitle(Text("Database Search Results"), displayMode: .inline)
        
    }   // End of body
}

struct SearchItemList_Previews: PreviewProvider {
    static var previews: some View {
        SearchItemList()
    }
}


