//
//  Home.swift
//  Cars
//
//  Created by Satwik Tadikamalla and Osman Balci on 11/20/22.
//  Copyright © 2022 Satwik Tadikamalla, Osman Balci. All rights reserved.
//


import SwiftUI
import CoreData

struct Home: View {
    
    // ❎ Core Data managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // ❎ Core Data FetchRequest returning all music Photo entities in the database
    @FetchRequest(fetchRequest: Car.allCarsFetchRequest()) var allCars: FetchedResults<Car>
    
    @AppStorage("darkMode") private var darkMode = false
    
    @State private var index = 0
    let angleCode = ["01", "05", "09", "13", "17", "22", "28", "29"]
    @State private var angleInd = 0
    
    /*
     Create a timer publisher that fires 'every' 3 seconds and updates the view.
     It runs 'on' the '.main' runloop so that it can update the view.
     It runs 'in' the '.common' mode so that it can run alongside other
     common events such as when the ScrollView is being scrolled.
     */
    @State private var timer = Timer.publish(every: 8, on: .main, in: .common).autoconnect()
    @State private var timerAngle = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        
        ScrollView(.vertical, showsIndicators: false) {
            VStack {
                ZStack {
                    // Center Welcome image horizontally across the screen
                    HStack {
                        Image("CarsLogo")
                            .resizable()
                            .frame(width: 250, height: 80, alignment: .center)
                    }
                }   // End of ZStack
                
                /*
                 ------------------------------------------------------------------------------
                 Show an image slider of the cover photos of all of the cars in the arrayOfMainCarsStructs.
                 ------------------------------------------------------------------------------
                 */
                getImageFromUrl(url: imageAnglePicker(imageUrl: allCars[index].imageUrl ?? "", angle: angleCode[angleInd]), defaultFilename: "ImageUnavailable")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(minWidth: 430, maxWidth: 500, alignment: .center)
                    .padding()
                    .onReceive(timerAngle) { _ in
                        angleInd += 1
                        if angleInd > angleCode.count - 1 {
                            angleInd = 0
                        }
                    }
                    // Subscribe to the timer publisher
                    .onReceive(timer) { _ in
                        index += 1
                        if index > allCars.count - 1 {
                            index = 0
                        }
                    }
                
                // Photo Description
                Text("Car Make: \(allCars[index].make?.uppercased() ?? "")\nCar Model: \(allCars[index].model?.uppercased() ?? "")")
                    .font(.headline)
                    // Allow lines to wrap around
//                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.center)
                    .padding(.bottom, 20)
                
                Text("Powered By")
                    .font(.system(size: 18, weight: .light, design: .serif))
                    .italic()
                
                // Show google books API website in default web browser
                Link(destination: URL(string: "https://api-ninjas.com/api/cars")!) {
                    HStack {
                        Image("ImageNinja")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 130)
                        Text("Ninja API")
                    }
                    
                }
                .padding()
                // Show Unsplash API website in default web browser
                Link(destination: URL(string: "https://docs.imagin.studio/cdnDatapoints")!) {
                    HStack {
                        Image("ImaginImage")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 130)
                        Text("Imagin API")
                    }
                }
                .padding()
                // Show Unsplash API website in default web browser
                Link(destination: URL(string: "https://fusion.yelp.com/")!) {
                    HStack {
                        Image("ImageYelp")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 130)
                        Text("Yelp Fusion API")
                    }
                }
//                Button("find item") {
//                    getFoundCarsFromApi(make: "honda", model: "accord", year: "2020" )
//                }
                .padding(.bottom, 20)
                
            }   // End of VStack
        }   // End of ScrollView
        .onAppear() {
            startTimer()
        }
        .onDisappear() {
            stopTimer()
        }
    }
    
    func startTimer() {
        timer = Timer.publish(every: 8, on: .main, in: .common).autoconnect()
        timerAngle = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    }
    
    func stopTimer() {
        timer.upstream.connect().cancel()
        timerAngle.upstream.connect().cancel()
    }
    
    func imageAnglePicker(imageUrl: String, angle: String) -> String {
        return imageUrl.dropLast(2) + angle
    }
    
}
