//
//  CarGridCustomization.swift
//  Cars
//
//  Created by Max Rojtman on 11/28/22.
//  Copyright © 2022 Max Rojtman. All rights reserved.
//

import SwiftUI
//var display = 100.0
var angle = "01"
struct GridSettings: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var userSettings: UserSettings
    
    let angleCode = ["01", "05", "09", "13", "29"]
//    let difficultyChoices = ["Easy", "Medium", "Hard", "Expert"]
//    let difficultyDescription = ["Guess the car manufacturer, bonus points if you can guess the model", "Guess the car year, bonus points if you can guess the fuel_type", "Guess the fuel efficiency", "Guess the cylinders and displacement"]
    
    let angleChoices = ["Front Orthographic", "Profile", "Rear Orthographic", "Rear", "Front"]
    let displayChoices = ["Standard", "Zoomed"]
    
    
    @State private var angleIndex = 0
    @State private var difficultyIndex = 0
    @State private var displayIndex = 0
    
    
    
    var body: some View {
        Form {
            
//            Section(header: Text("Difficulty")) {
//                VStack {
//                    Picker("", selection: $difficultyIndex) {
//                        ForEach(0 ..< difficultyChoices.count, id: \.self) {
//                            Text(difficultyChoices[$0])
//                        }
//                    }
//                    .pickerStyle(SegmentedPickerStyle())
//                    Text(difficultyDescription[difficultyIndex])
//                }
//            }
            
            Section(header: Text("Angle Picker")) {
                Picker("", selection: $angleIndex) {
                    ForEach(0 ..< angleChoices.count, id: \.self) {
                        Text(angleChoices[$0])
                    }
                }
                .pickerStyle(WheelPickerStyle())
                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
            }
            
            Section(header: Text("Display Zoom")) {
                VStack {
                    Picker("", selection: $displayIndex) {
                        ForEach(0 ..< displayChoices.count, id: \.self) {
                            Text(displayChoices[$0])
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    Text(displayIndex == 0 ? "Grid Consist of 3 Columns" : "Grid Consist of 2 Columns")
                }
            }
            
            Section(header: Text("Update Changes")) {
                HStack {
                    Spacer()
                    Button("Apply Changes") {
                        updateConfig()
                        dismiss()
                       
                    }
                    .tint(.blue)
                    .buttonStyle(.bordered)
                    .buttonBorderShape(.capsule)
                    
                    Spacer()
                }
            }
            
        }
        .navigationBarTitle(Text("Car Grid Settings"), displayMode: .inline)
    }
    
    
    func updateConfig() {
        userSettings.angle = angleCode[angleIndex]
        let display = Double(displayIndex) * 50.0 + 100.0
        userSettings.column = [GridItem(.adaptive(minimum: display), spacing: 5) ]
    }
    
}
