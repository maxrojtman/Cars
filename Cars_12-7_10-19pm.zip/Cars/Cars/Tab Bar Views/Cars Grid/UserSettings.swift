//
//  UserSettings.swift
//  Cars
//
//  Created by Max Rojtman on 11/28/22.
//  Copyright © 2022 Max Rojtman. All rights reserved.
//

import Combine
import SwiftUI

class UserSettings: ObservableObject {
    
    
    enum Difficulty: String {
        case Easy
        case Medium
        case Hard
        case Expert
    }

    
    @Published var difficulty: Difficulty
    
    @Published var angle: String
    @Published var size: CGFloat
    @Published var column: [GridItem]

//    init(angle: String, difficulty: Difficulty, size: CGFloat) {
//        self.difficulty = difficulty
//        self.angle = angle
//        self.size = size
//    }
    
        init() {
            self.difficulty = .Easy
            self.angle = "01"
            self.size = 100.0
            self.column = [GridItem(.adaptive(minimum: 100.0), spacing: 5) ]
        }
    
}
