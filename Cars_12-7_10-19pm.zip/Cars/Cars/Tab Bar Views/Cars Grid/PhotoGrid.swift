//
//  PhotosGrid.swift
//  MyDiary
//
//  Created by Osman Balci on 5/25/22.
//  Modified by Max Rojtman on 10/15/22.
//  Copyright © 2022 Osman Balci & Max Rojtman. All rights reserved.
//

import SwiftUI
import CoreData
import AVFoundation
var car_make = ""
var car_model = ""

struct CarsGrid: View {
    @EnvironmentObject private var userSettings: UserSettings
    // ❎ Core Data managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    // ❎ Core Data FetchRequest returning all music Photo entities in the database
    
    @FetchRequest(fetchRequest: Car.allCarsFetchRequest()) var allCars: FetchedResults<Car>

    /*
     Instantiate an object from the AVSpeechSynthesizer class and
     store its object reference into struct property speechSynthesizer.
     The AVSpeechSynthesizer object produces synthesized speech from text and
     provides methods for controlling or monitoring the progress of ongoing speech.
     */
    let speechSynthesizer = AVSpeechSynthesizer()
    let uiscreen = UIScreen.main.bounds
    @State private var showEntryInfoAlert = false
    @State private var selectedBgColor = Color.white.opacity(0.2)
    // Fit as many photos per row as possible with minimum image width of 100 points each.
    // spacing defines spacing between columns
    
    //var columns = [GridItem(.adaptive(minimum: display), spacing: 5) ]
    
    var body: some View {
        
        NavigationView { //used to add header
                ZStack {
//                    Rectangle()
//                            .fill(
//                                LinearGradient(gradient: Gradient(colors: [Color.clear, selectedBgColor]),
//                                               startPoint: .top,
//                                               endPoint: .bottom))
//                            .frame(width: self.uiscreen.width,
//                                   height: self.uiscreen.height,
//                                   alignment: .center)
                    selectedBgColor.edgesIgnoringSafeArea(.all)
                    VStack {
                        Text("Tap a car, see if you were right!")
                        ScrollView {
                            
                            // spacing defines spacing between rows
                            LazyVGrid(columns: userSettings.column, spacing: 5) {
                                // 🔴 id: \.self is required to prevent photos being listed as out of order
                                
                                
                                
                                ForEach(allCars, id: \.self) { car in
                                    // This public function is given in UtilityFunctions.swift
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 5, style: .continuous)
                                            .fill(.black)
                                            .opacity(0.30)
                                            .shadow(radius: 30)
                                        getImageFromUrl(url: imageAngle(imageUrl: car.imageUrl ?? ""), defaultFilename: "ImageUnavailable")
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .scaledToFit()
                                            .shadow(color: .white, radius: 30)
                                        // Speak photo info on tap gesture
                                            .onTapGesture {
                                                car_make = car.make ?? ""
                                                car_model = car.model ?? ""
                                                convertTextToSpeech()
                                            }
                                            .onLongPressGesture {
                                                car_make = car.make ?? ""
                                                car_model = car.model ?? ""
                                                showEntryInfoAlert = true
                                            }
                                    }
                                }
                            }   .padding(10)// End of LazyVGrid
                            Spacer()
                            //                .padding()
                            
                            
                        }   // End of ScrollView
                        
                    } //end Vstack
                    .navigationBarTitle(Text("Car Quiz"), displayMode: .inline)
                    .navigationBarItems(leading: NavigationLink(destination: GridSettings()) {
                        Image(systemName: "gear")
                    }, trailing:
                                            ColorPicker("", selection: $selectedBgColor))
                    .alert(isPresented: $showEntryInfoAlert, content: { entryInfoAlert })
                }
                
                //end ZStack
           } //end navigation view
    }   // End of body var
    
    //-----------------------
    // Convert Text to Speech
    //-----------------------
    func convertTextToSpeech() {
        
        let textToConvertToSpeech = "\(car_model) by \(car_make)"
        
        let audioSession = AVAudioSession.sharedInstance()
        
        do {
            /*
             Override the Output Audio Port of the audioSession by
             routing audio to the built-in speaker and microphone.
             */
            try
                audioSession.overrideOutputAudioPort(AVAudioSession.PortOverride.speaker)
        } catch {
            print("Unable to override the Output Audio Port!")
        }
        
        // Create an AVSpeechUtterance instance with the text to be spoken
        let speechUtterance = AVSpeechUtterance(string: textToConvertToSpeech)
        
        /*
         Set the speech language to English with U.S. dialect.
         Some of the English language dialects:
         English (Australia):         en-AU
         English (Ireland):           en-IE
         English (South Africa):      en-ZA
         English (United Kingdom):    en-GB
         English (United States):     en-US
         */
        speechUtterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        /*
         Set the speed (rate) at which entered text will be spoken;
         The higher the rate, the faster the speech will be.
         */
        speechUtterance.rate = 0.5
        
        /*
         Calling speechSynthesizer's speak method adds the speechUtterance to a queue;
         utterances are spoken in the order in which they are added to the queue.
         */
        speechSynthesizer.speak(speechUtterance)
    }
    
    var entryInfoAlert: Alert {
        Alert(title: Text(car_make.capitalized),
              message: Text("\(car_model.capitalized) by \(car_make.capitalized)"),
              dismissButton: .default(Text("OK")) )
    }
    
//    func interceptImageAngle(imageUrl: String) -> String {
//        var customImageUrl = imageUrl.dropLast(2)
//
//
//    }
    
    func imageAngle(imageUrl: String) -> String {
        return imageUrl.dropLast(2) + userSettings.angle
    }
}   // End of PhotosGrid struct


struct PhotosGrid_Previews: PreviewProvider {
    static var previews: some View {
        CarsGrid()
    }
}
