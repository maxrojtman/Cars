//
//  DealershipDetail.swift
//  Cars
//
//  Created by Yoshihiro Iketani on 11/26/22.
//

import SwiftUI
import MapKit

struct DealershipDetail: View {
    
    //---------
    // Map View
    //---------
    @State private var selectedMapTypeIndex = 0
    @State private var selectedDirectionMapTypeIndex = 0
    var mapTypes = ["Standard", "Satellite", "Hybrid", "Globe"]
    
    @State private var selectedTransportTypeIndex = 1
    let directionsTransportTypes = ["Driving", "Walking"]
    
    let dealership: DealershipStruct
    
    //---------------
    // Alert Messages
    //---------------
    @State private var showAlertMessage = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
    var body: some View {
        Form {
            Section(header: Text("Car Dealership Name")) {
                Text(dealership.name)
            }
            Section(header: Text("Car Dealership Address")) {
                Text(dealership.address)
            }
            if !(dealership.imageUrl.isEmpty) {
                Section(header: Text("Car Dealership Image")) {
                    getImageFromUrl(url: dealership.imageUrl, defaultFilename: "ImageUnavailable")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(minWidth: 300, maxWidth: 500, alignment: .center)
                        // Long press the photo image to display the context menu
                        .contextMenu {
                            // Context Menu Item
                            Button(action: {
                                // Copy the movie poster photo from the URL to universal clipboard for pasting elsewhere
                                UIPasteboard.general.image = getUIImageFromUrl(url: dealership.imageUrl, defaultFilename: "ImageUnavailable")
                                
                                showAlertMessage = true
                                alertTitle = "Car Dealership Image is Copied to Clipboard"
                                alertMessage = "You can paste it on your iPhone, iPad, Mac laptop or Mac desktop each running under your Apple ID"
                            }) {
                                Image(systemName: "doc.on.doc")
                                Text("Copy Photo")
                            }
                        }
                }
            }
            
            if dealership.reviewCount > -1 {
                Section(header: Text("Car Dealership Rating out of 5 Stars")) {
                    RatingView
                }
            }
            
            if !dealership.phoneNumber.isEmpty {
                Section(header: Text("Car Dealership Phone Number")){
                    HStack {
                        Image(systemName: "phone")
                            .imageScale(.medium)
                            .font(Font.title.weight(.light))
                            .foregroundColor(Color.blue)
                        
                        //**************************************************************************
                        // This Link does not work on the Simulator since Phone app is not available
                        //**************************************************************************
                        Link(dealership.phoneNumber, destination: URL(string: phoneNumberToCall(phoneNumber: dealership.phoneNumber))!)
                    }
                    .contextMenu {
                        // Context Menu Item 1
                        //**************************************************************************
                        // This Link does not work on the Simulator since Phone app is not available
                        //**************************************************************************
                        Link(destination: URL(string: phoneNumberToCall(phoneNumber: dealership.phoneNumber))!) {
                            Image(systemName: "phone")
                            Text("Call")
                        }
                        
                        // Context Menu Item 2
                        Button(action: {
                            // Copy the phone number to universal clipboard for pasting elsewhere
                            UIPasteboard.general.string = dealership.phoneNumber
                            
                            showAlertMessage = true
                            alertTitle = "Phone Number is Copied to Clipboard"
                            alertMessage = "You can paste it on your iPhone, iPad, Mac laptop or Mac desktop each running under your Apple ID"
                        }) {
                            Image(systemName: "doc.on.doc")
                            Text("Copy Phone Number")
                        }
                    }
                }
            }
            
            if !dealership.websiteUrl.isEmpty {
                Section(header: Text("Business Website")) {
                    // Tap the website URL to display the website externally in default web browser
                    Link(destination: URL(string: dealership.websiteUrl)!) {
                        HStack {
                            Image(systemName: "globe")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                            Text("Show Company Website")
                                .font(.system(size: 16))
                        }
                        .foregroundColor(.blue)
                    }
                    // Long press the website URL to display the context menu
                    .contextMenu {
                        // Context Menu Item
                        Button(action: {
                            // Copy the website URL to universal clipboard for pasting elsewhere
                            UIPasteboard.general.url = URL(string: dealership.websiteUrl)!
                            
                            showAlertMessage = true
                            alertTitle = "Website URL is Copied to Clipboard"
                            alertMessage = "You can paste it on your iPhone, iPad, Mac laptop or Mac desktop each running under your Apple ID"
                        }) {
                            Image(systemName: "doc.on.doc")
                            Text("Copy Website URL")
                        }
                    }
                }
            }
                
            if dealership.latitude > -300 {
                Section(header: Text("Business Location on Map")) {
                   
                    Picker("Select Map Type", selection: $selectedMapTypeIndex) {
                        ForEach(0 ..< mapTypes.count, id: \.self) { index in
                           Text(mapTypes[index])
                       }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .padding(.horizontal)
                   
                    NavigationLink(destination: dealerLocationOnMap) {
                        HStack {
                            Image(systemName: "mappin.and.ellipse")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                            Text("Show Car Dealership Location on Map")
                                .font(.system(size: 16))
                        }
                        .foregroundColor(.blue)
                    }
                }
                
                Section(header: Text("Directions to the Car Dealership")) {
                    VStack {
                        Text("Select Directions Transport Type")
                        Picker("Transport Type", selection: $selectedTransportTypeIndex) {
                            ForEach(0 ..< directionsTransportTypes.count, id: \.self) { index in
                                Text(directionsTransportTypes[index]).tag(index)
                            }
                        }
                            .pickerStyle(SegmentedPickerStyle())
                            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
                        
                        Text("Select Map Type")
                        Picker("Select Map Type", selection: $selectedDirectionMapTypeIndex) {
                            ForEach(0 ..< mapTypes.count, id: \.self) { index in
                                Text(mapTypes[index]).tag(index)
                            }
                        }
                            .pickerStyle(SegmentedPickerStyle())
                            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
                        NavigationLink(destination: showDirectionsOnMap) {
                            HStack {
                                Image(systemName: "arrow.up.right.diamond")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                                Text("Show Directions on Map")
                                    .font(.system(size: 16))
                            }
                            .foregroundColor(.blue)
                        }
                    }
                }
            }
        }   // End of Form
            .navigationBarTitle(Text("Car Dealership Details"), displayMode: .inline)
            .font(.system(size: 14))    // Set font and size for all Text views in the Form
            .alert(alertTitle, isPresented: $showAlertMessage, actions: {
                Button("OK") {}
            }, message: {
                Text(alertMessage)
            })
    }
    
    func phoneNumberToCall(phoneNumber: String) -> String {
        // phoneNumber = (540) 231-4841
        
        let cleaned1 = phoneNumber.replacingOccurrences(of: " ", with: "")
        let cleaned2 = cleaned1.replacingOccurrences(of: "(", with: "")
        let cleaned3 = cleaned2.replacingOccurrences(of: ")", with: "")
        let cleanedNumber = cleaned3.replacingOccurrences(of: "-", with: "")
        
        // cleanedNumber = 5402314841
        
        return "tel:" + cleanedNumber
    }
    
    func roundedRating(rating: Double) -> Double{
        //let ratingDouble  = Double(rating)!
        let x = Double(round(10 * rating) / 10)
        return x
    }
    
    var dealerLocationOnMap: some View {
       
        var mapType: MKMapType
      
        switch selectedMapTypeIndex {
        case 0:
            mapType = MKMapType.standard
        case 1:
            mapType = MKMapType.satellite
        case 2:
            mapType = MKMapType.hybrid
        case 3:
            mapType = MKMapType.hybridFlyover   // Globe
        default:
            fatalError("Map type is out of range!")
        }
       
        return AnyView(
            MapView(mapType: mapType,
                    latitude: dealership.latitude,
                    longitude: dealership.longitude,
                    delta: 0.1,
                    deltaUnit: "degrees",
                    annotationTitle: dealership.name,
                    annotationSubtitle: dealership.phoneNumber)
            
            .navigationBarTitle(Text(dealership.name), displayMode: .inline)
        )
    }
    
    var showDirectionsOnMap: some View {
        
        var mapType: MKMapType
        
        switch selectedMapTypeIndex {
        case 0:
            mapType = MKMapType.standard
        case 1:
            mapType = MKMapType.satellite
        case 2:
            mapType = MKMapType.hybrid
        default:
            fatalError("Map type is out of range!")
        }
        
        var transportType: MKDirectionsTransportType
        
        switch selectedTransportTypeIndex {
        case 0:
            transportType = .automobile
        case 1:
            transportType = .walking
        default:
            fatalError("Transport type is out of range!")
        }
        
        let currentGeolocation = currentLocation()
        let latitudeFrom = currentGeolocation.latitude
        let longitudeFrom = currentGeolocation.longitude
        
        return AnyView(
            VStack {
                // Display "from current location to where" as centered multi lines
                Text("\(directionsTransportTypes[selectedTransportTypeIndex]) Directions")
                    .font(.custom("Helvetica", size: 10))
                    .fixedSize(horizontal: false, vertical: true)   // Allow lines to wrap around
                    .multilineTextAlignment(.center)
                
                // Display directions on map
                DirectionsOnMap(latitudeFrom:   latitudeFrom,
                                longitudeFrom:  longitudeFrom,
                                latitudeTo:     dealership.latitude,
                                longitudeTo:    dealership.longitude,
                                mapType: mapType,
                                directionsTransportType: transportType)
                
                    .navigationBarTitle(Text("\(directionsTransportTypes[selectedTransportTypeIndex]) Directions"), displayMode: .inline)
            }
        )
    }
    
    var RatingView: some View {
        return AnyView (
            HStack (spacing: 0, content: {
                HStack(spacing: 0, content: {
                    let ratingNSNumber = Int(dealership.rating)
                    
                    ForEach(1..<ratingNSNumber+1, id: \.self) { number in
                        Image(systemName: "star.fill")
                            .foregroundColor(.blue)
                    }
                    let ratingThreshold = Double(ratingNSNumber) + 0.2
                    if roundedRating(rating: dealership.rating) > ratingThreshold {
                        Image(systemName: "star.leadinghalf.filled")
                            .foregroundColor(.blue)
                    }
                })
                Text(" based on \(dealership.reviewCount) reviews")
            })
        )
    }
}
