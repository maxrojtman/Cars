//
//  SearchDealers.swift
//  Cars
//
//  Created by Yoshihiro Iketani on 11/27/22.
//

import SwiftUI

struct SearchDealers: View {
    
    @State private var searchLocation = ["Current Location", "Location Entered"]
    @State private var locIndex = 0
    
    @State private var sortMethod = ["Best Match", "Rating", "Review Count", "Distance"]
    @State private var sortIndex = 0
    
    let maxNumberList = [10, 20, 30, 40]
    @State private var selectedNumberIndex = 0
    
    let distanceList = [10, 20, 30, 40]
    @State private var distanceIndex = 0
    
    @State private var searchLocationFieldValue = ""
    @State private var searchTermFieldValue = ""
    
    @State private var searchCompleted = false
    
    //---------------
    // Alert Messages
    //---------------
    @State private var showAlertMessage = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
    var body: some View {
        Form {
            // Button for searching database.
            Section(header: Text("Select Search Location")) {
                VStack {
                    Picker("", selection: $locIndex) {
                        ForEach(0 ..< searchLocation.count, id: \.self) {
                            Text(searchLocation[$0])
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                }
            }
            
            if (locIndex == 1){
                Section(header: Text("Enter Location")) {
                    HStack {
                        TextField("Enter Location", text: $searchLocationFieldValue)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .disableAutocorrection(true)
                        
                        // Button to clear the text field
                        Button(action: {
                            searchLocationFieldValue = ""
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }   // End of HStack
                }
            }
            else {
                // Choose the radius around the user to search.
                Section(header: Text("Search Radius Around the User"), footer: Text("Search for dealership within the selected search radius in kilometers (km)").italic()) {
                    Picker("Search Radius", selection: $distanceIndex) {
                        ForEach(0 ..< distanceList.count, id: \.self) { index in
                            Text("\(distanceList[index])")
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
                }
            }
            
            Section(header: Text("Select the Sorting Method")) {
                if (locIndex == 1) {
                    VStack {
                    Picker("Sorting", selection: $sortIndex) {
                        ForEach(0 ..< sortMethod.count-1, id: \.self) {
                            Text(sortMethod[$0])
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    }
                }
                else {
                    VStack {
                    Picker("Sorting", selection: $sortIndex) {
                        ForEach(0 ..< sortMethod.count, id: \.self) {
                            Text(sortMethod[$0])
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    }
                }
            }
            
            Section(header: Text("Enter Make or Dealership Name")) {
                HStack {
                    TextField("Enter Search Query", text: $searchTermFieldValue)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .disableAutocorrection(true)
                    
                    // Button to clear the text field
                    Button(action: {
                        searchTermFieldValue = ""
                    }) {
                        Image(systemName: "clear")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                    }
                }   // End of HStack
            }
            
            // Choose the maximum number of results to obtain.
            Section(header: Text("Maximum Results to Return")) {
                Picker("Number of Results", selection: $selectedNumberIndex) {
                    ForEach(0 ..< maxNumberList.count, id: \.self) { index in
                        Text("\(maxNumberList[index])")
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
            }
            
            Section(header: Text("Search For Car Dealership")) {
                HStack {
                    Spacer()
                    Button(searchCompleted ? "Search Completed" : "Search") {
                        if inputDataValidated() {
                            searchYelpApi()
                            searchCompleted = true
                        } else {
                            showAlertMessage = true
                            alertTitle = "Missing Input Data!"
                            alertMessage = "Location is required! Search term is optional."
                        }
                    }
                    .tint(.blue)
                    .buttonStyle(.bordered)
                    .buttonBorderShape(.capsule)
                    
                    Spacer()
                }   // End of HStack
            }
            
            // When the search is completed.
            if searchCompleted {
                // Show the list of businesses found.
                Section(header: Text("Show Dealerships Found")) {
                    NavigationLink(destination: showDealerSearchResults) {
                        HStack {
                            Image(systemName: "list.bullet")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                            Text("List Dealerships Found")
                                .font(.system(size: 16))
                        }
                        .foregroundColor(.blue)
                    }
                }
                
                // Button to clear search result.
                Section(header: Text("Clear")) {
                    HStack {
                        Spacer()
                        Button("Clear") {
                            searchCompleted = false
                        }
                        .tint(.blue)
                        .buttonStyle(.bordered)
                        .buttonBorderShape(.capsule)
                        Spacer()
                    }
                }
            }
        }   // End of Form
        .navigationBarTitle(Text("Search For Car Dealerships"), displayMode: .inline)
        .alert(alertTitle, isPresented: $showAlertMessage, actions: {
            Button("OK") {}
        }, message: {
            Text(alertMessage)
        })
    }
    
    /*
     ---------------------------
     MARK: Input Data Validation
     ---------------------------
     */
    func inputDataValidated() -> Bool {
        
        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        if locIndex == 1 {
            let locationQueryTrimmed = searchLocationFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
            
            if locationQueryTrimmed.isEmpty {
                return false
            }
        }
        return true
    }

    /*
     -------------------------
     MARK: Show Search Results
     -------------------------
     */
    var showDealerSearchResults: some View {
        
        // Global array foundDealersList is given in YelpData.swift
        if foundDealersList.isEmpty {
            if (locIndex == 1) {
                return AnyView(
                    NotFound(message: "API Search Produced No Results!\n\nThe API did not return any value for the given search query!")
                )
            }
            else {
                return AnyView(
                    NotFound(message: "API Search Produced No Results!\n\nThe API did not return any value for near your location!")
                )
            }
        }
        
        return AnyView(DealershipsList())
    }
    
    /*
     ---------------------
     MARK: Search Yelp API
     ---------------------
     */
    func searchYelpApi() {
        var searchUrl = "https://api.yelp.com/v3/businesses/search?"
        
        let termQuery = searchTermFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if locIndex == 0 {
            let currentGeolocation = currentLocation()
            let latitudeFrom = currentGeolocation.latitude
            let longitudeFrom = currentGeolocation.longitude
            
            searchUrl.append("latitude=\(latitudeFrom)&longitude=\(longitudeFrom)&radius=\(distanceList[distanceIndex]*1000)&categories=car_dealers")
        }
        else{
            // Remove spaces, if any, at the beginning and at the end of the entered search query string
            let locationQuery = searchLocationFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
            
            searchUrl.append("location=\(locationQuery)&categories=car_dealers")
        }
        
        searchUrl.append("&limit=\(maxNumberList[selectedNumberIndex])")
        
        if !termQuery.isEmpty {
            searchUrl.append("&term=\(termQuery)")
        }
        
        if sortIndex == 0 {
            searchUrl.append("&sort_by=best_match")
        }
        if sortIndex == 1 {
            searchUrl.append("&sort_by=rating")
        }
        if sortIndex == 2 {
            searchUrl.append("&sort_by=review_count")
        }
        if sortIndex == 3 {
            searchUrl.append("&sort_by=distance")
        }
            
        // Replace all occurrences of space within the search URL with %+, which is the UTF-8 encoding of space.
        var yelpApiSearchQuery = searchUrl.replacingOccurrences(of: " ", with: "+")
        
        // Replace all occurrences of space within the search URL with "", which is the UTF-8 encoding of space.
        yelpApiSearchQuery = yelpApiSearchQuery.replacingOccurrences(of: ",", with: "")
        
        // getYelpApiData public function is given in YelpData.swift file
        getYelpApiData(apiUrlString: yelpApiSearchQuery)
    }
}
