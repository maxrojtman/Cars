//
//  DealershipItem.swift
//  Cars
//
//  Created by Yoshihiro Iketani on 11/27/22.
//

import SwiftUI

struct DealershipItem: View {
    
    let dealership: DealershipStruct
    
    var body: some View {
        HStack {
            getImageFromUrl(url: dealership.imageUrl, defaultFilename: "ImageUnavailable")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100)
            VStack(alignment: .leading) {
                Text(dealership.name)
                HStack {
                    Image(systemName: "phone")
                        .font(.system(size: 10, weight: .regular))
                    Text(dealership.phoneNumber)
                }
                Text("\(roundedRating(rating: dealership.rating)) stars rating")
            }   // End of VStack
            .font(.system(size: 14))
        }   // End of HStack
        
    }
    
    func roundedRating(rating: Double) -> String{
        //let ratingDouble  = Double(rating)!
        let x = Double(round(10 * rating) / 10)
        print(x)
        return "\(x)"
    }
}
