//
//  DealershipsList.swift
//  Cars
//
//  Created by Yoshihiro Iketani on 11/27/22.
//

import SwiftUI

struct DealershipsList: View {
    var body: some View {
        List {
            ForEach(foundDealersList, id: \.self) { aDealer in
                NavigationLink(destination: DealershipDetail(dealership: aDealer)) {
                    DealershipItem(dealership: aDealer)
                }
            }
        }
        .navigationBarTitle(Text("Car Dealership Search Results"), displayMode: .inline)
    }
}
