//
//  More.swift
//  Companies
//
//  Created by Satwik Tadikamalla and Osman Balci on 11/8/22.
//  Copyright © 2022 Satwik Tadikamalla, Osman Balci. All rights reserved.
//

import SwiftUI

struct More: View {
    
    var body: some View {
        NavigationView {
            List {
                NavigationLink(destination: SearchNewCar()) {
                    HStack {
                        Image(systemName: "magnifyingglass.circle")
                            .imageScale(.large)
                            .font(Font.title.weight(.regular))
                            .frame(width: 60)
                        Text("Ninja API")
                            .font(.system(size: 16))
                    }
                    .foregroundColor(.blue)
                }
                NavigationLink(destination: SearchDealers()) {
                    HStack {
                        Image(systemName: "magnifyingglass.circle.fill")
                            .imageScale(.large)
                            .font(Font.title.weight(.regular))
                            .frame(width: 60)
                        Text("Search For Car Dealerships")
                            .font(.system(size: 16))
                    }
                    .foregroundColor(.blue)
                }
                    NavigationLink(destination: Settings()) {
                        HStack {
                            Image(systemName: "gear")
                                .imageScale(.large)
                                .font(Font.title.weight(.regular))
                                .frame(width: 60)
                            Text("Settings")
                                .font(.system(size: 16))
                        }
                        .foregroundColor(.blue)
                    }
                    
                }   // End of List
                .navigationBarTitle(Text("More"), displayMode: .inline)
                
            }   // End of NavigationView
            // Use single column navigation view for iPhone and iPad
            .navigationViewStyle(StackNavigationViewStyle())
        }
    }


struct More_Previews: PreviewProvider {
    static var previews: some View {
        More()
    }
}
