//
//  FoundCarDetails.swift
//  Cars
//
//  Created by Satwik Tadikamalla on 11/22/22.
//



import SwiftUI

struct FoundCarDetails: View {
    
    let car: FoundCar
    
    @AppStorage("darkMode") private var darkMode = false
    
    var body: some View {
        Form {
            Group {
                Section(header: Text("Car Make")) {
                    Text(car.make)
                }
                Section(header: Text("Car Model")) {
                    Text(car.model)
                }
                Section(header: Text("Car Year")) {
                    Text(String(car.year))
                }
                Section(header: Text("Car Class")) {
                    Text(car.classType)
                }
                
            }
            Group {
//                Text("Fuel Information".uppercased())
//                    .font(.system(size: 22, weight: .medium, design: .serif))
//                    .textFieldStyle(.plain)
                Section(header: Text("Car Fuel Type")) {
                    Text(car.fuel_type)
                }
                Section(header: Text("Car Combination MPG")) {
                    Text("\(car.combination_mpg)")
                }
                Section(header: Text("Car Highway MPG")) {
                    Text("\(car.highway_mpg)")
                }
                Section(header: Text("Car City MPG")) {
                    Text("\(car.city_mpg)")
                }
            }
            Group {
//                Text("Car Engine Information".uppercased())
//                    .font(.system(size: 22, weight: .medium, design: .serif))
//                    .textFieldStyle(.plain)
                Section(header: Text("Car Transmission")) {
                    if car.transmission == "a" {
                        Text("Automatic")
                    } else {
                        Text("Manual")
                    }
                    
                }
                Section(header: Text("Car Cylinders")) {
                    Text("\(car.cylinders)")
                }
                Section(header: Text("Car Displacement")) {
                    Text(String(car.displacement))
                }

            }
        }
    }
}
