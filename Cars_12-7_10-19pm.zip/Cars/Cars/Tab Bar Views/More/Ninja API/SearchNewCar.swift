//
//  SearchApi.swift
//  Companies
//
//  Created by Satwik Tadikamalla and Osman Balci on 11/22/22.
//  Copyright © 2022 Satwik Tadikamalla, Osman Balci. All rights reserved.
//

import SwiftUI

struct SearchNewCar: View {
    
    //---------------
    // Alert Messages
    //---------------
    @State private var showAlertMessage = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
    //-----------------
    // Search Variables
    //-----------------
    @State private var makeFieldValue = ""
    @State private var modelFieldValue = ""
    @State private var yearFieldValue = ""
    @State private var searchCompleted = false
    
    var body: some View {
        Form {
            Section(header: Text("Enter Make").padding(.top, 30)) {
                HStack {
                    TextField("Enter Make", text: $makeFieldValue)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .disableAutocorrection(true)
                    
                    // Button to clear the text field
                    Button(action: {
                        makeFieldValue = ""
                        showAlertMessage = false
                        searchCompleted = false
                    }) {
                        Image(systemName: "clear")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                    }
                }
            }
            Section(header: Text("Enter Model").padding(.top, 30)) {
                HStack {
                    TextField("Enter Model", text: $modelFieldValue)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .disableAutocorrection(true)
                    
                    // Button to clear the text field
                    Button(action: {
                        modelFieldValue = ""
                        showAlertMessage = false
                        searchCompleted = false
                    }) {
                        Image(systemName: "clear")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                    }
                }
            }
            Section(header: Text("Enter Car Year").padding(.top, 30)) {
                HStack {
                    TextField("Enter Car Year", text: $yearFieldValue)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .disableAutocorrection(true)
                    
                    // Button to clear the text field
                    Button(action: {
                        yearFieldValue = ""
                        showAlertMessage = false
                        searchCompleted = false
                    }) {
                        Image(systemName: "clear")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                    }
                }
            }
            Section(header: Text("Search Cars")) {
                HStack {
                    Spacer()
                    Button(searchCompleted ? "Search Completed" : "Search") {
                        if inputDataValidatedAPI() {
                            foundCarsStructs.removeAll()
                            searchApi()
                            searchCompleted = true
                        } else {
                            showAlertMessage = true
                            alertTitle = "Search Field is Empty!"
                            alertMessage = "Make is required! Model and Year Term is Optional"
                        }
                    }
                    .tint(.blue)
                    .buttonStyle(.bordered)
                    .buttonBorderShape(.capsule)
                    
                    Spacer()
                }
            }
            
            if searchCompleted {
                Section(header: Text("Show Cars Found")) {
                    NavigationLink(destination: showSearchResult) {
                        HStack {
                            Image(systemName: "list.bullet")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                            Text("Show Cars Found")
                                .font(.system(size: 16))
                        }
                        .foregroundColor(.blue)
                    }
                }
            }
            
        }   // End of Form
        .navigationBarTitle(Text("Search Cars"), displayMode: .inline)
        .alert(alertTitle, isPresented: $showAlertMessage, actions: {
            Button("OK") {}
        }, message: {
            Text(alertMessage)
        })
        
        .customNavigationViewStyle()  // Given in NavigationStyle.swift
        
    }   // End of body var
    
    func searchApi() {
        
        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        let makeTrimmed = makeFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let modelTrimmed = modelFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let yearTrimmed = yearFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // public func getFoundCarsFromApi is given in NinjaAPICars.swift
        getFoundCarsFromApi(make: makeTrimmed, model: modelTrimmed, year: yearTrimmed)
        
    }
    
    var showSearchResult: some View {
            return AnyView(FoundCarList())
        
    }
    
    /*
     ---------------------------
     MARK: Input Data Validation
     ---------------------------
     */
    func inputDataValidatedAPI() -> Bool {
        
        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        let queryTrimmed = makeFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if queryTrimmed.isEmpty {
            print(queryTrimmed)
            return false
        }
        return true
    }
    
    struct SearchNewCar_Previews: PreviewProvider {
        static var previews: some View {
            SearchNewCar()
        }
    }
}
