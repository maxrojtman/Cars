//
//  FoundCarList.swift
//  Cars
//
//  Created by Satwik Tadikamalla on 11/22/22.
//

import SwiftUI

struct FoundCarList: View {
    
    var body: some View {
        List {
            ForEach(foundCarsStructs) { aCar in
                NavigationLink(destination: FoundCarDetails(car: aCar)) {
                    FoundCarItem(car: aCar)
                }
            }
        }
        .navigationBarTitle(Text("Car Search Results"), displayMode: .inline)
        
    }   // End of body
}

struct FoundCarList_Previews: PreviewProvider {
    static var previews: some View {
        FoundCarList()
    }
}
