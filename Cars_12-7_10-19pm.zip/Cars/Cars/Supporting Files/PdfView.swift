//
//  PdfView.swift
//  Cars
//
//  Created by Satwik Tadikamalla on 12/5/22.
//  Copyright © 2022 Max Rojtman. All rights reserved.
//

import Foundation
import PDFKit
import SwiftUI


struct PdfView: UIViewRepresentable {
    var url: URL
    
    init(_ url: URL) {
        self.url = url
    }
    
    func makeUIView(context: UIViewRepresentableContext<PdfView>) -> PdfView.UIViewType {
        
        let pdfview = PDFView()
        pdfview.document = PDFDocument(url: self.url)
        return pdfview
        
    }
    func updateUIView(_ uiView: UIView, context: UIViewRepresentableContext<PdfView>) {
            // Update the view.
        }
}
