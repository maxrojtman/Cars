//
//  Car.swift
//  Cars
//
//  Created by Akhil Kamalesh and Osman Balci on 11/21/22.
//  Copyright © 2022 Akhil Kamalesh, Osman Balci. All rights reserved.
//

import Foundation
import CoreData

// ❎ Core Data Company entity public class
public class Car: NSManagedObject, Identifiable {

    // Attributes
    @NSManaged public var orderNumber: NSNumber?
    @NSManaged public var city_mpg: NSNumber?
    @NSManaged public var classType: String? 
    @NSManaged public var combination_mpg: NSNumber?
    @NSManaged public var cylinders: NSNumber?
    @NSManaged public var displacement: NSNumber?
    @NSManaged public var drive: String?
    @NSManaged public var fuel_type: String?
    @NSManaged public var highway_mpg: NSNumber?
    @NSManaged public var make: String?
    @NSManaged public var model: String?
    @NSManaged public var transmission: String?
    @NSManaged public var year: NSNumber?
    @NSManaged public var imageUrl: String?
    @NSManaged public var pdfUrl: String?

}

extension Car {
    /*
     ❎ CoreData @FetchRequest in FavoritesList.swift invokes this class method
        to fetch all of the Company entities from the database.
        The 'static' keyword designates the func as a class method invoked by using the
        class name as Company.allCompaniesFetchRequest() in any .swift file in your project.
     */
    static func allCarsFetchRequest() -> NSFetchRequest<Car> {
        /*
         Create a fetchRequest to fetch Company entities from the database.
         Since the fetchRequest's 'predicate' property is not set to filter,
         all of the Company entities will be fetched.
         */
        let fetchRequest = NSFetchRequest<Car>(entityName: "Car")

        fetchRequest.sortDescriptors = [
            // List the fetched Company entities in ascending order with respect to orderNumber
            NSSortDescriptor(key: "orderNumber", ascending: true)
        ]
        
        return fetchRequest
    }

}

