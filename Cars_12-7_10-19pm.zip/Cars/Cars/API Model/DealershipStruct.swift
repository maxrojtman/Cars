//
//  DealershipStruct.swift
//  Cars
//
//  Created by Yoshihiro Iketani on 11/26/22.
//

import SwiftUI

struct DealershipStruct: Decodable, Identifiable, Hashable {
    
    var id: UUID
    var latitude: Double
    var longitude: Double
    var phoneNumber: String
    var imageUrl: String
    var address: String
    var name: String
    var rating: Double
    var reviewCount: Int
    var websiteUrl: String
       
}
