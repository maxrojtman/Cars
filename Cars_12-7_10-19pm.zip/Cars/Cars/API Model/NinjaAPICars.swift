//
//  NinjaAPICars.swift
//  Cars
//
//  Created by Satwik Tadikamalla and Osman Balci on 11/20/22.
//  Copyright © 2022 Satwik Tadikamalla, Osman Balci. All rights reserved.
//

import Foundation

let APIKey = "PtCTHkWktNQwoYBNdhrhRg==dQDVkP0rmEhPlBC5"

// Global variable to contain the API search results
var foundCarsStructs = [FoundCar]()

/*
    ************************************
    *   Yelp Fusion API HTTP Headers   *
    ************************************
    */
//    let carApiHeaders = [
//        "accept": "application/json",
//        "authorization": "X-Api-Key PtCTHkWktNQwoYBNdhrhRg==dQDVkP0rmEhPlBC5",
//        "cache-control": "no-cache",
//        "connection": "keep-alive",
//        "host": "api.api-ninjas.com"
//    ]


public func getFoundCarsFromApi(make: String, model: String, year: String) {
    
    let yearInt: Int32? = Int32(year)
    // Initialize the global variable to contain the API search results
    var foundCar = FoundCar(id: UUID(), orderNumber: 0, city_mpg: 0, classType: "", combination_mpg: 0, cylinders: 0, displacement: 0, drive: "", fuel_type: "", highway_mpg: 0, make: "", model: "", transmission: "", year: 0, imageUrl: "")
//    let carModel = ["accord", "civic", "camry", "corolla", "elantra", "sonata", "altima", "silverado", "malibu", "rav4", "cr-v", "tacoma"]
    
    /*
     ***************************************
     *   Obtaining API Search URL String   *
     ***************************************
     */
    //    var apiUrlString = "https://api.api-ninjas.com/v1/cars?limit=5&make=\(make)&model=\(model)year=\(year)"
    
    var url = URL(string: "https://api.api-ninjas.com/v1/cars?limit=5&make=\(make)")!
    if(!model.isEmpty) {
        url = URL(string: "https://api.api-ninjas.com/v1/cars?limit=5&make=\(make)&model=\(model)")!
    }
    
    var request = URLRequest(url: url)
    request.setValue(APIKey, forHTTPHeaderField: "X-Api-Key")
    let task = URLSession.shared.dataTask(with: request) {(data, response, error) in
        guard let data = data else { return }
        print("\(make), \(model), \(year)")
 
        
        do {
            let jsonResponse = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers)
        
            if let carArray = jsonResponse as? NSArray {
                
                for item in 0...carArray.count-1 {
                    let curCar = carArray[item] as? NSDictionary
                    
                    foundCar.id = UUID()
                    foundCar.make = curCar!["make"] as! String
                    foundCar.model = curCar!["model"] as! String
                    foundCar.year = yearInt ?? 2022
                    foundCar.city_mpg = curCar!["city_mpg"] as! Int32
                    foundCar.classType = curCar!["class"] as! String
                    foundCar.combination_mpg = curCar!["combination_mpg"] as! Int32
                    foundCar.cylinders = curCar!["cylinders"] as! Int32
                    foundCar.displacement = curCar!["displacement"] as! Double
                    foundCar.drive = curCar!["drive"] as! String
                    foundCar.fuel_type = curCar!["fuel_type"] as! String
                    foundCar.highway_mpg = curCar!["highway_mpg"] as! Int32
                    foundCar.transmission = curCar!["transmission"] as! String
                    foundCar.orderNumber = Int32(arrayOfMainCarsStructs.count + 1)
                    foundCar.imageUrl = "https://cdn.imagin.studio/getImage?customer=usvirginia-tech-student&make=\(make)&modelFamily=\(model)&angle=01"
                    foundCarsStructs.append(foundCar)
                }
            }
        } catch {
            print("jsonResponse didnt work")
            return
        }
        
    }
    task.resume()
        
    
}
