//
//  YelpData.swift
//  Cars
//
//  Created by Yoshihiro Iketani and Osman Balci on 11/27/22.
//  Copyright © 2022 Yoshihiro Iketani, Osman Balci. All rights reserved.
//

import Foundation

// Global variable to contain the API search results
var foundDealersList = [DealershipStruct]()

// Yelp API Key
let yelpApiKey = "3Icb3Qg5ArjpT9swQuKLv7HOi4o1RfNpDOt43RAaK5QWm8F0UaeTIjOiV_IGJZH8puqtlPy0Xv80omQntH0k3bRMkhhkUzXeqUIYZ16ZKhxYwxxFmM6DTK7resByY3Yx"

/*
************************************
*   Yelp Fusion API HTTP Headers   *
************************************
*/
let yelpFusionApiHeaders = [
    "accept": "application/json",
    "authorization": "Bearer \(yelpApiKey)",
    "cache-control": "no-cache",
    "connection": "keep-alive",
    "host": " api.yelp.com"
]

/*
 ========================================================
 |   Fetch and Process JSON Data from the API for       |
 |   a Business with its location and/or name given     |
 ========================================================
*/
public func getYelpApiData(apiUrlString: String){
    
    // Initialize the global variable to contain the API search results
    foundDealersList = [DealershipStruct]()
    
    /*
    ***************************************************
    *   Fetch JSON Data from the API Asynchronously   *
    ***************************************************
    */
    var jsonDataFromApi: Data
    
    let jsonDataFetchedFromApi = getJsonDataFromApi(apiHeaders: yelpFusionApiHeaders, apiUrl: apiUrlString, timeout: 20.0)
    
    if let jsonData = jsonDataFetchedFromApi {
        jsonDataFromApi = jsonData
    } else {
        return
    }
    
    /*
    **************************************************
    *   Process the JSON Data Fetched from the API   *
    **************************************************
    */
    do {
        let jsonResponse = try JSONSerialization.jsonObject(with: jsonDataFromApi,
                         options: JSONSerialization.ReadingOptions.mutableContainers)
        
        //-----------------------------
        // Obtain Top Level JSON Object
        //-----------------------------
        var jsonDataDictionary = [String: Any]()
        
        if let jsonObject = jsonResponse as? [String: Any] {
           jsonDataDictionary = jsonObject
        } else {
           return
        }
        
        //--------------------------
        // Obtain Results JSON Array
        //--------------------------
        var arrayOfBusinesses = [Any]()
        
        if let jArray = jsonDataDictionary["businesses"] as? [Any] {
            arrayOfBusinesses = jArray
        } else {
            return
        }
        
        // Iterate over the array
        for aBusiness in arrayOfBusinesses {
            // Initialization for new Business
            var latitude = -300.0, longitude = -300.0, phoneNumber = "", imageUrl = "", address = "", name = "", rating = -1.0, reviewCount  = -1, websiteUrl = ""
            
            let business = aBusiness as? [String: Any]
            print("start")
            print(business!)
            print("end")
            
            // Get coordinate information
            if let coordinates = business!["coordinates"] as? [String: Any] {
                // obtain latitude
                if let obtainedLatitude = coordinates["latitude"] as? NSNumber {
                    latitude = obtainedLatitude.doubleValue;
                }
                else {
                    continue
                }
                
                // obtain longitude
                if let obtainedLongitude = coordinates["longitude"] as? NSNumber {
                    longitude = obtainedLongitude.doubleValue;
                }
                else {
                    continue
                }
            }
            
            if let phoneString = business!["display_phone"] as? String {
                phoneNumber = phoneString;
            }
            
            if let obtainedImage = business!["image_url"] as? String{
                imageUrl = obtainedImage
            }
            
            if let addresses = business!["location"] as? [String: Any] {
                if let address1 = addresses["address1"]  as? String {
                    if !(address1.isEmpty){
                        address.append("\(address1), ")
                    }
                }
                if let address2 = addresses["address2"]  as? String {
                    if !(address2.isEmpty){
                        address.append("\(address2), ")
                    }
                }
                if let address3 = addresses["address3"]  as? String {
                    if !(address3.isEmpty){
                        address.append("\(address3), ")
                    }
                }
                
                if let city = addresses["city"] as? String {
                    address.append("\(city), ")
                }
                
                if let state = addresses["state"] as? String {
                    address.append("\(state), ")
                }
                
                if let zip = addresses["zip_code"] as? String {
                    address.append("\(zip), ")
                }
                
                if let country = addresses["country"] as? String {
                    address.append("\(country)")
                }
                else {
                    continue
                }
            }
            else {
                // Skip this business
                continue
            }
            
            if let obtainedName = business!["name"] as? String {
                name = obtainedName
            }
            else{
                continue
            }
            
            if let obtainedRating = business!["rating"] as? Double {
                rating = Double(round(10 * obtainedRating) / 10)
            }
            
            if let obtainedCount = business!["review_count"] as? Int {
                reviewCount = obtainedCount
            }
            
            if let webUrl = business!["url"] as? String {
                websiteUrl = webUrl
            }
            else{
                continue
            }
            
            //-------------------------------------------------------------------------
            // Create an Instance of DealershipStruct Struct and Append it to the List
            //-------------------------------------------------------------------------
            let newDealer = DealershipStruct(id: UUID(), latitude: latitude, longitude: longitude, phoneNumber: phoneNumber, imageUrl: imageUrl, address: address, name: name, rating: rating, reviewCount: reviewCount, websiteUrl: websiteUrl)
            
            foundDealersList.append(newDealer)
        }   // End of for loop
    } catch { return }
}
