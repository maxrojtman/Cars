//
//  FoundCarStruct.swift
//  Cars
//
//  Created by Satwik Tadikamalla on 11/22/22.
//

import Foundation

struct FoundCar: Decodable, Identifiable {
    
    var id: UUID
    var orderNumber: Int32
    var city_mpg: Int32
    var classType: String
    var combination_mpg: Int32
    var cylinders: Int32
    var displacement: Double
    var drive: String
    var fuel_type: String
    var highway_mpg: Int32
    var make: String
    var model: String
    var transmission: String
    var year: Int32
    var imageUrl: String
}
