//
//  MainViewCarStruct.swift
//  Cars
//
//  Created by Satwik Tadikamalla on 11/20/22.
//

import Foundation

struct MainCar: Decodable {
    
    var orderNumber: Int32
    var city_mpg: Int32
    var classType: String
    var combination_mpg: Int32
    var cylinders: Int32
    var displacement: Double
    var drive: String
    var fuel_type: String
    var highway_mpg: Int32
    var make: String
    var model: String
    var transmission: String
    var year: Int32
    var color: String
    var imageUrl: String
    var pdfUrl: String
}
/*
 
 var cylinders: Int32
 var displacement: Int32
 var drive: String
 var fuel_type: String
 var highway_mpg: Int32
 var make: String
 var model: String
 var transmission: String
 var year: Int32
 var imageUrl: String
 */
/*
 
 "cylinders": 4,
 "displacement": 2.2,
 "drive": "fwd",
 "fuel_type": "gas",
 "highway_mpg": 27,
 "make": "honda",
 "model": "accord",
 "transmission": "a",
 "year": 2022,
 "imageUrl": "https://cdn.imagin.studio/getImage?customer=usvirginia-tech-student&make=honda&modelFamily=accord&modelYear=2022&angle=01"
 
 {
     "orderNumber": 2,
     "city_mpg": 25,
     "Class": "subcompact car",
     "combination_mpg": 28,
     "cylinders": 4,
     "displacement": 1.5,
     "drive": "fwd",
     "fuel_type": "gas",
     "highway_mpg": 33,
     "make": "honda",
     "model": "civic",
     "transmission": "a",
     "year": 2022,
     "imageUrl": "https://cdn.imagin.studio/getImage?customer=usvirginia-tech-student&make=honda&modelFamily=civic&modelYear=2022&angle=01"
 },
 {
     "orderNumber": 3,
     "city_mpg": 18,
     "Class": "midsize car",
     "combination_mpg": 21,
     "cylinders": 4,
     "displacement": 2.2,
     "drive": "fwd",
     "fuel_type": "gas",
     "highway_mpg": 26,
     "make": "toyota",
     "model": "camry",
     "transmission": "a",
     "year": 2022,
     "imageUrl": "https://cdn.imagin.studio/getImage?customer=usvirginia-tech-student&make=toyota&modelFamily=camry&modelYear=2022&angle=01"
 },
 {
     "orderNumber": 4,
     "city_mpg": 23,
     "Class": "small sport utility vehicle",
     "combination_mpg": 26,
     "cylinders": 4,
     "displacement": 2.5,
     "drive": "fwd",
     "fuel_type": "gas",
     "highway_mpg": 30,
     "make": "toyota",
     "model": "rav4",
     "transmission": "a",
     "year": 2022,
     "imageUrl": "https://cdn.imagin.studio/getImage?customer=usvirginia-tech-student&make=toyota&modelFamily=rav4&modelYear=2022&angle=01"
 },
 {
     "orderNumber": 5,
     "city_mpg": 22,
     "Class": "small sport utility vehicle",
     "combination_mpg": 24,
     "cylinders": 4,
     "displacement": 2,
     "drive": "fwd",
     "fuel_type": "gas",
     "highway_mpg": 28,
     "make": "mercedes-benz",
     "model": "glc300",
     "transmission": "a",
     "year": 2022,
     "imageUrl": "https://cdn.imagin.studio/getImage?customer=usvirginia-tech-student&make=mercedes&modelFamily=glc&modelYear=2022&angle=01"
 },
 {
     "orderNumber": 6,
     "city_mpg": 17,
     "Class": "subcompact car",
     "combination_mpg": 20,
     "cylinders": 6,
     "displacement": 3,
     "drive": "rwd",
     "fuel_type": "gas",
     "highway_mpg": 26,
     "make": "bmw",
     "model": "m3",
     "transmission": "a",
     "year": 2022,
     "imageUrl": "https://cdn.imagin.studio/getImage?customer=usvirginia-tech-student&make=bmw&modelFamily=m3&modelYear=2022&angle=01"
 },
 {
     "orderNumber": 7,
     "city_mpg": 17,
     "Class": "compact car",
     "combination_mpg": 19,
     "cylinders": 6,
     "displacement": 2.8,
     "drive": "fwd",
     "fuel_type": "gas",
     "highway_mpg": 22,
     "make": "audi",
     "model": "a6",
     "transmission": "a",
     "year": 2022,
     "imageUrl": "https://cdn.imagin.studio/getImage?customer=usvirginia-tech-student&make=audi&modelFamily=a6&modelYear=2022&angle=01"
 }
 */
