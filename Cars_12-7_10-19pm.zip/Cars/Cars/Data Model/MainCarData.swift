//
//  MainCarData.swift
//  Cars
//
//  Created by Satwik Tadikamalla and Osman Balci on 11/20/22.
//  Copyright © 2022 Satwik Tadikamalla, Osman Balci. All rights reserved.
//
import SwiftUI
import CoreData

var arrayOfMainCarsStructs = [MainCar]()
var listOfAllCarEntitiesInDB = [Car]()

public func createMainCarStructs() {
    
    PersistenceController.shared.clearDatabase()
    
    // ❎ Get object reference of Core Data managedObjectContext from the persistent container
    let managedObjectContext = PersistenceController.shared.persistentContainer.viewContext
    
    //----------------------------
    // ❎ Define the Fetch Request
    //----------------------------
    let fetchRequest = NSFetchRequest<Car>(entityName: "Car")
    fetchRequest.sortDescriptors = [NSSortDescriptor(key: "orderNumber", ascending: true)]
    var listOfAllCarEntitiesInDB = [Car]()
    
    do {
        
        listOfAllCarEntitiesInDB = try managedObjectContext.fetch(fetchRequest)
    } catch {
        print("Database Creation Failed!")
        return
    }

    if listOfAllCarEntitiesInDB.count > 0 {
        print("Database has already been created!")
        return
    }

    print("Database will be created!")
    
    
    arrayOfMainCarsStructs = [MainCar]()
    
    arrayOfMainCarsStructs = decodeJsonFileIntoArrayOfStructs(fullFilename: "CarsBasicData.json", fileLocation: "Main Bundle")
    
    for aCar in arrayOfMainCarsStructs {
        /*
         =============================
         *   Car entity Creation   *
         =============================
         */
        
        // 1️⃣ Create an instance of the Photo Entity in managedObjectContext
        let carEntity = Car(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attributes
        carEntity.orderNumber = aCar.orderNumber as NSNumber
        carEntity.city_mpg = (aCar.city_mpg) as NSNumber
        carEntity.classType = aCar.classType
        carEntity.combination_mpg = (aCar.combination_mpg) as NSNumber
        carEntity.cylinders = (aCar.cylinders) as NSNumber
        carEntity.displacement = (aCar.displacement) as NSNumber
        carEntity.drive = aCar.drive
        carEntity.fuel_type = aCar.fuel_type
        carEntity.highway_mpg = (aCar.highway_mpg) as NSNumber
        carEntity.make = aCar.make
        carEntity.model = aCar.model
        carEntity.transmission = aCar.transmission
        carEntity.year = (aCar.year) as NSNumber
        carEntity.imageUrl = aCar.imageUrl //must be part of same entity since images not in assets
        carEntity.pdfUrl = aCar.pdfUrl

        
        
    }   // End of for loop
    
    // ❎ Save Changes to Core Data Database
//    print("came")
    PersistenceController.shared.saveContext()

}   // End of function
