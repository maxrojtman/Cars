//
//  ContentView.swift
//  Cars
//
//  Created by Satwik Tadikamalla and Osman Balci on 11/8/22.
//  Copyright © 2022 Satwik Tadikamalla, Osman Balci. All rights reserved.
//

import SwiftUI
import CoreData

struct ContentView: View {
    @EnvironmentObject private var userSettings: UserSettings
    @Environment(\.managedObjectContext) private var viewContext
    
    var body: some View {
        TabView {
            Home()
                .tabItem {
                    Image(systemName: "house")
                    Text("Home")
                }
            
            FavoriteCarList()
                .tabItem {
                    Image(systemName: "car")
                    Text("Favorite Cars")
                }
            CarsGrid()
                .tabItem {
                    Image(systemName: "square.grid.3x2")
                    Text("Cars Grid")
                }
            SearchDatabase()
                .tabItem {
                    Image(systemName: "magnifyingglass")
                    Text("Search DB")
                }
            More()
                .tabItem {
                    Image(systemName: "ellipsis")
                    Text("More")
                }
        }   // End of TabView
        .font(.headline)
        .imageScale(.medium)
        .font(Font.title.weight(.regular))
    }
}
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
